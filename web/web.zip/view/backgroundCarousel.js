$(function() {
	// set transition to 3s
	$('.carousel').carousel({
		interval: 5000,
		cicle: true
	}); 
});
