$(function() {
	// set transition to 3s
	$('.carousel').carousel({
		interval: 3000,
		cicle: true
	}); 
});
